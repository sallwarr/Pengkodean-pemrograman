<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $nama_barang = $_POST['nama_barang'];
    $jenis_barang = $_POST['jenis_barang'];
    $satuan_barang = $_POST['satuan_barang'];
    $merk_barang = $_POST['merk_barang'];
    $jumlah = $_POST['jumlah'];
    $supplier = $_POST['supplier'];
    $harga_jual = $_POST['harga_jual'];
    $harga_beli = $_POST['harga_beli'];
    $stok = $_POST['stok'];

    $stmt = $pdo->prepare("UPDATE barang SET nama_barang = ?, jenis_barang = ?, satuan_barang = ?, merk_barang = ?, jumlah = ?, supplier = ?, harga_jual = ?, harga_beli = ?, stok = ? WHERE id = ?");
    $stmt->execute([$nama_barang, $jenis_barang, $satuan_barang, $merk_barang, $jumlah, $supplier, $harga_jual, $harga_beli, $stok, $id]);

    // Redirect kembali ke dashboard
    header("Location: index.php");
    exit();
}
?>