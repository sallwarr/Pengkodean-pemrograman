<?php
include 'config.php';

// Ambil data barang untuk tabel
$stmt_barang = $pdo->query("SELECT * FROM barang");
$barang = $stmt_barang->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PT SAR - Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Hamburger Menu -->
        <div class="hamburger">
            <i class="fas fa-bars"></i>
        </div>

        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <img src="images/strawberry.png" alt="Strawberry Logo" class="logo-img"> PT SAR
            </div>
            <ul class="menu">
                <li class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</li>
                <li><i class="fas fa-cubes"></i> Jenis Barang</li>
                <li><i class="fas fa-tag"></i> Merk Barang</li>
                <li><i class="fas fa-boxes"></i> Master Barang</li>
                <li><i class="fas fa-users"></i> Customer</li>
                <li><i class="fas fa-exchange-alt"></i> Transaksi</li>
                <li><i class="fas fa-file-alt"></i> Laporan</li>
            </ul>
            <ul class="other">
                <li><i class="fas fa-cog"></i> Settings</li>
                <li><i class="fas fa-sign-out-alt"></i> Logout</li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <div class="user-info">
                    <span>PT SAR</span>
                    <img src="images/strawberry.png" alt="Strawberry Logo" class="avatar">
                </div>
            </div>
            <div class="breadcrumb">
                <span>Admin</span> / <span>Dashboard</span>
            </div>
            <h1>Dashboard</h1>

            <!-- Tombol Tambah Barang -->
            <button class="btn-tambah" onclick="document.getElementById('tambahModal').style.display='block'">
                <i class="fas fa-plus"></i> Tambah Barang
            </button>

            <!-- Tabel Barang -->
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Barang</th>
                            <th>Jenis Barang</th>
                            <th>Satuan Barang</th>
                            <th>Merk Barang</th>
                            <th>Jumlah</th>
                            <th>Supplier</th>
                            <th>Harga Jual</th>
                            <th>Harga Beli</th>
                            <th>Stok</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; foreach ($barang as $item): ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td><?php echo $item['nama_barang']; ?></td>
                                <td><?php echo $item['jenis_barang']; ?></td>
                                <td><?php echo $item['satuan_barang']; ?></td>
                                <td><?php echo $item['merk_barang']; ?></td>
                                <td><?php echo $item['jumlah']; ?></td>
                                <td><?php echo $item['supplier']; ?></td>
                                <td><?php echo number_format($item['harga_jual'], 2, ',', '.'); ?></td>
                                <td><?php echo number_format($item['harga_beli'], 2, ',', '.'); ?></td>
                                <td><?php echo $item['stok']; ?></td>
                                <td>
                                    <button class="btn-edit" onclick="document.getElementById('editModal<?php echo $item['id']; ?>').style.display='block'">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                    <a href="hapus_barang.php?id=<?php echo $item['id']; ?>" class="btn-hapus" onclick="return confirm('Apakah Anda yakin ingin menghapus barang ini?')">
                                        <i class="fas fa-trash"></i> Hapus
                                    </a>
                                </td>
                            </tr>

                            <!-- Modal Edit Barang -->
                            <div id="editModal<?php echo $item['id']; ?>" class="modal">
                                <div class="modal-content">
                                    <span class="close" onclick="document.getElementById('editModal<?php echo $item['id']; ?>').style.display='none'">×</span>
                                    <h2>Edit Barang</h2>
                                    <form action="edit_barang.php" method="POST">
                                        <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
                                        <div class="form-group">
                                            <label for="nama_barang">Nama Barang</label>
                                            <input type="text" id="nama_barang" name="nama_barang" value="<?php echo $item['nama_barang']; ?>" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="jenis_barang">Jenis Barang</label>
                                            <input type="text" id="jenis_barang" name="jenis_barang" value="<?php echo $item['jenis_barang']; ?>" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="satuan_barang">Satuan Barang</label>
                                            <input type="text" id="satuan_barang" name="satuan_barang" value="<?php echo $item['satuan_barang']; ?>" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="merk_barang">Merk Barang</label>
                                            <input type="text" id="merk_barang" name="merk_barang" value="<?php echo $item['merk_barang']; ?>" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="jumlah">Jumlah</label>
                                            <input type="number" id="jumlah" name="jumlah" value="<?php echo $item['jumlah']; ?>" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="supplier">Supplier</label>
                                            <input type="text" id="supplier" name="supplier" value="<?php echo $item['supplier']; ?>" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="harga_jual">Harga Jual</label>
                                            <input type="number" step="0.01" id="harga_jual" name="harga_jual" value="<?php echo $item['harga_jual']; ?>" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="harga_beli">Harga Beli</label>
                                            <input type="number" step="0.01" id="harga_beli" name="harga_beli" value="<?php echo $item['harga_beli']; ?>" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="stok">Stok</label>
                                            <input type="number" id="stok" name="stok" value="<?php echo $item['stok']; ?>" required>
                                        </div>
                                        <button type="submit" class="btn-submit">Simpan</button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal Tambah Barang -->
    <div id="tambahModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="document.getElementById('tambahModal').style.display='none'">×</span>
            <h2>Tambah Barang</h2>
            <form action="tambah_barang.php" method="POST">
                <div class="form-group">
                    <label for="nama_barang">Nama Barang</label>
                    <input type="text" id="nama_barang" name="nama_barang" required>
                </div>
                <div class="form-group">
                    <label for="jenis_barang">Jenis Barang</label>
                    <input type="text" id="jenis_barang" name="jenis_barang" required>
                </div>
                <div class="form-group">
                    <label for="satuan_barang">Satuan Barang</label>
                    <input type="text" id="satuan_barang" name="satuan_barang" required>
                </div>
                <div class="form-group">
                    <label for="merk_barang">Merk Barang</label>
                    <input type="text" id="merk_barang" name="merk_barang" required>
                </div>
                <div class="form-group">
                    <label for="jumlah">Jumlah</label>
                    <input type="number" id="jumlah" name="jumlah" required>
                </div>
                <div class="form-group">
                    <label for="supplier">Supplier</label>
                    <input type="text" id="supplier" name="supplier" required>
                </div>
                <div class="form-group">
                    <label for="harga_jual">Harga Jual</label>
                    <input type="number" step="0.01" id="harga_jual" name="harga_jual" required>
                </div>
                <div class="form-group">
                    <label for="harga_beli">Harga Beli</label>
                    <input type="number" step="0.01" id="harga_beli" name="harga_beli" required>
                </div>
                <div class="form-group">
                    <label for="stok">Stok</label>
                    <input type="number" id="stok" name="stok" required>
                </div>
                <button type="submit" class="btn-submit">Simpan</button>
            </form>
        </div>
    </div>

    <script src="js/script.js"></script>
</body>
</html>